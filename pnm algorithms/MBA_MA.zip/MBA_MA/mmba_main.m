clear
clc
close all
tic
%% Load in Data
load('');
A = imstore;%(1:50,1:50,1:50)
% set = 3;
res = 5.35; %Image resolution
conn = 26; %6 26
%% Preprocessing
% A = circ_crop(A,set); %Circular for dataset
[A,skl] = mmba_prepcs(A,conn);
%% Maximum Inscribed spheres
[skl_inds,skl_sbs,m_spheres,con_s] = mmba_mis(A,skl);
disp('Max-Inscribed Spheres Complete')
toc    
%% MBA
[m_spheres] = mba(A,m_spheres,con_s);
disp('MBA Complete')
toc
%% dilate map
[families,lm] = fill_map(A,m_spheres);
disp('Dilation Complete')
toc
%% connect
[cons,con_inds,families] = con_mba(lm,families,conn);
disp('Connectivity Analysis Complete')
toc
%% thrt
prs = throat_analysis(lm,families,cons,con_inds,res);
disp('PNM Complete')
toc
%% sfp
% [s_prs, f_prs] = sfp(A,families);
%% perm
% K = perm_calc(A,prs,cons,res,families,s_prs,f_prs);
% disp('perm calculation Complete')
% toc
% %% make graph
% n_t = array2table(cell2mat(families(:,1)),"VariableNames",{'X','Y','Z'});
% G = graph(cons(:,1),cons(:,2),cons(:,3),n_t);
% disp('Graph Creation Complete')
% toc
% %% tortuosity
% anlys = tort_pnm(G,s_prs,f_prs);
% thyd = tort_hyd(families,anlys,A);
% tv = tort_voxel(A,families,anlys);
% 
% tb = [mean(A,'all')*100 size(families,1) size(cons,1) mean(cell2mat(families(:,2)))*res...
%     mean(2*prs(:,3))*res mean(prs(:,4))*res mean(cell2mat(families(:,4))) mean(thyd)];
