function [skl_inds,skl_sbs,m_spheres,con_s] = mmba_mis(A,skl)
%% Remove edges
%% find seed points
skl_inds = find(skl == 1);
[skl_sbs(:,2),skl_sbs(:,1),skl_sbs(:,3)] = ind2sub(size(A),find(skl == 1));
%% Transform and store
D = bwdist(1-A);
sds = [skl_sbs double(D(skl_inds)) skl_inds];
%% void array
re = sortrows(sds,4,'descend'); %Sort void EDT largest-smallest
%% Distance calculation (Most computation time here)
disp('MIS Starting')
tic
idx=0;
rmax = re(1,4);
while idx ~= size(re,1)
    idx = idx+1;
    x = re(idx,1); y = re(idx,2); z = re(idx,3); r =  re(idx,4);
    in = x-re(idx,4)-rmax<re(:,1)&re(:,1)<x+re(idx,4)+rmax...
    &y-re(idx,4)-rmax<re(:,2)&re(:,2)<y+re(idx,4)+rmax...
    &z-re(idx,4)-rmax<re(:,3)&re(:,3)<z+re(idx,4)+rmax;
    in = re(in,:);
    in(in(:,5) == re(idx,5),:) = [];
    dist = (pdist2([x y z],in(:,1:3))).'; 
    rmv = (dist<r);
    rmv_i = in(rmv,5);
    in(:,4) = in(:,4) + r;
    c_t = in(:,4)>dist;
    con_s{idx,1} = in(logical(c_t-rmv),5);
    re(ismember(re(:,5),rmv_i),:) = [];
    if rem(idx,1000) == 0
        disp(['MIS Progress: ', num2str((idx/size(re,1))*100)])
        toc
    end
end
%% Data Clearing
m_spheres = re;
%% Test Plotting
% x = m_spheres(:,1); y = m_spheres(:,2); z = m_spheres(:,3); r = m_spheres(:,4);
% figure();
% for p = 1:length(m_spheres)
%     p
%     xt = x(p); yt=y(p); zt=z(p);
%     [i, j, k] = sphere;
%     rt = r(p);
%     surf(i*rt+xt,j*rt+yt,k*rt+zt,'FaceColor',[0.5 0.5 0.5],'EdgeColor','none','FaceAlpha',0.3)
%     hold on
% %     xlim([0 d(1)]); ylim([0 d(2)]);zlim([0 d(3)]);
% end
end