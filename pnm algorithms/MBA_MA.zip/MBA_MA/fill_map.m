function [families,lm] = fill_map(A,m_spheres)
lm = zeros(size(A));
[px,py,pz] = meshgrid(1:size(A,2), 1:size(A,1), 1:size(A,3));
p = gcp('nocreate'); % If no pool, do not create new one.
if isempty(p)
    parpool
end
C = parallel.pool.Constant(m_spheres);
N = size(m_spheres, 1); %Total number of calculations 
ppm = ParforProgressStarter2('filling lm', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
ppm = ParforProgress2('filling lm',N); 
parfor i = 1:size(m_spheres,1) 
    x = C.Value(i,1); y = C.Value(i,2); z = C.Value(i,3); r = C.Value(i,4);
    sph_inds{i,1} = find((px-x).^2 + (py-y).^2 + (pz-z).^2 <=r*r);
    ppm.increment(i);
end
delete(ppm)
for i = 1:numel(sph_inds)
    lm(sph_inds{i,1}) = m_spheres(i,6);
end
disp('indices of spheres assigned')
%% distance map fills
rl = (A==1 & lm ==0);
lm_tmp = lm>0;
[~,I] = bwdist(lm_tmp);
lm(rl) = lm(I(rl));
families=table2cell(regionprops3(lm,'EquivDiameter','Centroid','VoxelIdxList'));
%% Plotting
% figure()
% for i = 1:2%size(families,1)%numel(fam)
% %     i
%     colour = rand(1,3);
%     inds = families{i,3};
%     [y,x,z] = ind2sub(size(lm),inds);
%     k = boundary(x,y,z);
%     trisurf(k,x,y,z,'FaceColor',colour,'EdgeColor','none','FaceAlpha',1)%[0.8 0.8 0.8]
%     hold on
% %     scatter3(x,y,z,20,'filled','MarkerEdgeColor','r','MarkerFaceColor','r')
%     disp(['Families surfaced: ', num2str(i), '/', num2str(size(families,1))])
% end
%% scatter plot
%     [i_sbs(:,2),i_sbs(:,1),i_sbs(:,3)] = ind2sub(size(A),families{cons(3,1),3});
%     scatter3(i_sbs(:,1),i_sbs(:,2),i_sbs(:,3),"filled")
%     hold on
%     clear i_sbs
%     [i_sbs(:,2),i_sbs(:,1),i_sbs(:,3)] = ind2sub(size(A),families{cons(3,2),3});
%     scatter3(i_sbs(:,1),i_sbs(:,2),i_sbs(:,3),"filled")
%     clear i_sbs
end