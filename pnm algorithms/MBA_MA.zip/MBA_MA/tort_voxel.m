function tv = tort_voxel(A,families,anlys)
    anlys = anlys{3};
    conn = 26;
    load('nbh_dists.mat');
    if conn == 6
        dists = dists{1};
    elseif conn == 18
        dists = dists{2};
    elseif conn == 26
        dists = dists{3};
    end
    inds = find(A);
%     [y,x,z] = ind2sub(size(A),inds);
%     sbs = [x y z];
%     n_t = array2table(sbs,"VariableNames",{'X','Y','Z'});
    nbhs = find_nbhs(A,inds,conn);
    prs = nbhs.*A(nbhs);
    %% Find Voxel connection
    cons = cell(numel(inds),1);
    C = parallel.pool.Constant(prs);
    N = numel(inds); %Total number of calculations 
    ppm = ParforProgressStarter2('pth prms', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
    ppm = ParforProgress2('pth prms',N);
   for i = 1:numel(inds)
        locs = prs(i,:)>inds(i);
        cons{i,1} = [repmat(inds(i),sum(locs),1) prs(i,locs).' dists(locs).'];
        ppm.increment(i)
    end
    delete(ppm)
    cons = cell2mat(cons);
    sns = string(cons(:,1));
    fns = string(cons(:,2));
    G = graph(sns,fns,cons(:,3),string(inds));
    %% Path finding
    [v_all(:,2),v_all(:,1),v_all(:,3)] = ind2sub(size(A),inds);
    C = parallel.pool.Constant(families);
    D = parallel.pool.Constant(anlys);
    N = size(anlys, 1); %Total number of calculations 
    ppm = ParforProgressStarter2('pth prms', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
    ppm = ParforProgress2('pth prms',N);
    for i = 1:size(anlys,1)
        spt = round(C.Value{D.Value{i,1},1});
        si = sub2ind(size(A),spt(2),spt(1),spt(3));
        if A(si) == 0
            [~,idx] = pdist2(v_all,spt,'euclidean','Smallest',1);
            spt = v_all(idx,:);
            si = sub2ind(size(A),spt(2),spt(1),spt(3));
        end
        si = find(inds == si);
        fpt = round(C.Value{D.Value{i,2},1});
        fi = sub2ind(size(A),fpt(2),fpt(1),fpt(3));
        if A(fi) == 0
            [~,idx] = pdist2(v_all,fpt,'euclidean','Smallest',1);
            fpt = v_all(idx,:);
            fi = sub2ind(size(A),fpt(2),fpt(1),fpt(3));
        end
        fi = find(inds == fi);
        [P,L] = shortestpath(G,si,fi);
        dist = pdist2(spt,fpt);
        tv(i,1) = L/dist;
    end
    %% Locate values for graph
%     locs = cell(numel(inds),1);
%     N = numel(inds); %Total number of calculations 
%     ppm = ParforProgressStarter2('pth prms', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
%     ppm = ParforProgress2('pth prms',N);
%     parfor i = 1:numel(inds)
%         locs{i,1} = find(cons(:,1:2) == inds(i));
%         ppm.increment(i)
%     end
%     delete(ppm)
    %% change
    for i = 1:numel(inds)
        i
        cons(cons == inds(i)) = i;
    end
    G = graph(cons(:,1),cons(:,2),cons(:,3),n_t);
% 
end