function [m_spheres] = mba(A,m_spheres,con_s)
%% initialise
f = 0;
comp = 0;
%% pre-pro
m_spheres(:,6:8) = [zeros(size(m_spheres,1),1) inf(size(m_spheres,1),1) (1:size(m_spheres,1)).'];
groups = unique(m_spheres(:,4),'stable');
% groups = groups(groups>1);
%% mba
for i = 1:numel(groups)
    disp(['MBA ',num2str(i),'/',num2str(length(groups))])
    for j = 1:sum(m_spheres(:,4) == groups(i))
        grp = m_spheres(m_spheres(:,4) == groups(i),:);
        grp = sortrows(grp,7,'ascend');
        sph_i = grp(j,:);
        if sph_i(6) == 0
            f = f+1;
            fam = f;
            gen = 2;
            sph_i(6:7) = [fam 1];
        else
            fam = sph_i(6);
            gen = sph_i(7) + 1;
        end 
        sph_loc = m_spheres(:,5) == sph_i(5);
        atch = con_s{sph_loc};
        atch_l = ismember(m_spheres(:,5),atch);
        atch_s = m_spheres(atch_l,:);
        sph_ab = atch_s(:,6) == 0;
            if any(sph_ab) == 1 
                atch_s(sph_ab,6:7) = repmat([fam gen],sum(sph_ab),1);
            end
        whl = [sph_i;atch_s];
        whl = sortrows(whl,4,'descend');
        m_spheres(logical(sph_loc+atch_l),:) = whl;
        m_spheres = sortrows(m_spheres,8,'ascend');
        comp = comp+1;
    end
end
%% plotting
% % [px,py,pz] = meshgrid(1:size(A,2), 1:size(A,1), 1:size(A,3));
% figure()
% for i = 1:size(families,1)
%     colour = rand(1,3);
%     for j = 1:size(families{i,1},1)
%         x = families{i,1}(j,1); y = families{i,1}(j,2); z = families{i,1}(j,3); r = families{i,1}(j,4);
%         [m, n, p,] = sphere(10);
%         surf(m.*r+x,n.*r+y,p.*r+z,'FaceColor',colour,'EdgeColor', 'none', 'FaceAlpha',0.8);
%         hold on
% %         axis off
%     end
%     disp(['Families surfaced: ', num2str(i), '/', num2str(size(families,1))])
% end
% ind = unique(cell2mat(cellfun(@(x)cell2mat(x),throats(:,1), 'UniformOutput', false)));
% [y,x,z] = ind2sub(size(A),ind);
% scatter3(x,y,z,20,'filled','MarkerEdgeColor','r','MarkerFaceColor','r')
%% vol Plotting
% figure()
% for p = 1:length(se)
%     space = zeros(size(A));
%     colour = rand(1,3);
%     sphs = families{se(p),1}(:,1:3);
%     sphs = ismember(m_spheres(:,1:3),sphs,'rows');
%     inds = unique(cell2mat(m_spheres_t(sphs,2)));
%     [y,x,z] = ind2sub(size(A),inds);
%     k = boundary(x,y,z);
%     trisurf(k,x,y,z,'FaceColor',colour,'EdgeColor','none')
%     hold on
%     disp(['Families surfaced: ', num2str(p), '/', num2str(size(families,1))])
% %     xlim([0 164]); ylim([0 164]); zlim([1 2])
% end  
end