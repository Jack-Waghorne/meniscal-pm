function A = circ_crop(A,set)
imageSizeX = size(A,2);
imageSizeY = size(A,1);
[columnsInImage rowsInImage] = meshgrid(1:imageSizeX, 1:imageSizeY);
% Next create the circle in the image.
% VOI = [162 162] r = 157  \\ VOI(1) = [162 162] r = 157  \\ VOI(2) = [185 185] r = 182  \\ VOI(3) = [82 82] r = 82
if set == 0 || set == 1
centerX = 162;
centerY = 162;
radius = 159;
% elseif set == 1
% centerX = 162;
% centerY = 162;
% radius = 160;
elseif set == 2
centerX = 186;
centerY = 186;
radius = 183;
elseif set == 3
centerX = 82.5;
centerY = 82.5;
radius = 79;
elseif set == 4
centerX = 82.5;
centerY = 82;
radius = 81;
end
circlePixels = (rowsInImage - centerY).^2 + (columnsInImage - centerX).^2 >= radius.^2;
A = logical(A+circlePixels);