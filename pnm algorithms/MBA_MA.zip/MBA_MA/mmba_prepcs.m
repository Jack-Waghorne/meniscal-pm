function [A,skl] = mmba_prepcs(A,conn)
A = 1-A;
A = bwmorph3(A,'majority');
A = imopen(A,strel('sphere',2));
A = imclose(A,strel('sphere',2));

A = imfill(A, 'holes');
skl = bwskel(logical(A));%,'MinBranchLength',50
L = bwconncomp(skl);
szs = cellfun(@length,L.PixelIdxList);
[~,idx] = max(szs);
skl = zeros(size(skl));
skl(L.PixelIdxList{idx}) = 1;
end
