function [lm,rl,families] = wsgt(A,res)
B=bwdist(1-A,'cityblock');
B = medfilt3(B,[5,5,5]);
% B = imgaussfilt3(B,0.6);
B = -B;
B(~A) = Inf;
lm=watershed(B);
lm(~A) = 0;
rl = find(lm == 0 & A == 1);
families=table2cell(regionprops3(lm,'EquivDiameter','Centroid'));
%% fill using distance map
lm_tmp = lm>0;
[~,I] = bwdist(lm_tmp);
lm(rl) = lm(I(rl));
f_t=table2cell(regionprops3(lm,'VoxelIdxList'));
families(:,3) = f_t;
%% Family creation
families=table2cell(regionprops3(lm,'EquivDiameter','Centroid','VoxelIdxList'));
%% Distributions
% subplot(2,2,1)
% histogram(cell2mat(families(:,2)),25);%
% title('Pore Size Distribution')
% xlabel('Pore Diameter (Microns)'); ylabel('Frequency')
%% Plotting
% figure()
% for i = 1:length(families)%size(families,1)
%     colour = rand(1,3);
%     inds = families{(i),3};
%     [y,x,z] = ind2sub(size(A),inds);
%     k = boundary(x,y,z);
%     trisurf(k,x,y,z,'FaceColor',colour,'EdgeColor','none','FaceAlpha',0.3)%[0.8 0.8 0.8]
%     hold on
% %     scatter3(x,y,z,20,'filled','MarkerEdgeColor','r','MarkerFaceColor','r')
%     disp(['Families surfaced: ', num2str(i), '/', num2str(size(families,1))])
% end
end