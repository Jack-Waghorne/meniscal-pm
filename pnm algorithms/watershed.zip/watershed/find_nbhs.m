function nbhs = find_nbhs(M,inds,conn)
    [sbs(:,2),sbs(:,1),sbs(:,3)] = ind2sub(size(M),inds);
    if conn == 6
        dx = [-1 0 0 0 0 1];
        dy = [0 1 -1 0 0 0];
        dz = [0 0 0 1 -1 0];
    elseif conn == 18
        dx = [-1 -1 -1 -1 -1 0 0 0 0 0 0 0 0 1 1 1 1 1];
        dy = [1 0 0 0 -1 1 1 1 0 0 -1 -1 -1 1 0 0 0 -1];
        dz = [0 0 -1 1 0 -1 0 1 -1 1 -1 0 1 0 -1 0 1 0];
    elseif conn == 26
        [dx,dy,dz]=ndgrid([-1,0,1]);
        dx=dx(:).'; dy=dy(:).'; dz=dz(:).';
        dx(14) = []; dy(14) = []; dz(14) = []; 
    end
    X=sbs(:,1)+dx; Y=sbs(:,2)+dy; Z=sbs(:,3)+dz; %neighbor coordinates 
    tfx = (X<1 | X>size(M,2));
    tfy = (Y<1 | Y>size(M,1));
    tfz = (Z<1 | Z>size(M,3));
    tf = tfx | tfy | tfz;
    X(tf) = 1;
    Y(tf) = 1;
    Z(tf) = 1;
    nbhs = sub2ind(size(M),Y,X,Z);
    v = find(M==0,1);
    nbhs(tf) = v;
end