%%Tort analysis 
%% Build skel
B = imfill(A, 'holes');
skl = bwskel(logical(B));%,'MinBranchLength',50
L = bwconncomp(skl);
szs = cellfun(@length,L.PixelIdxList);
[~,idx] = max(szs);
skl = zeros(size(skl));
skl(L.PixelIdxList{idx}) = 1;
skl_inds = find(skl == 1);
[skl_sbs(:,2),skl_sbs(:,1),skl_sbs(:,3)] = ind2sub(size(A),find(skl == 1));
skl_t = A - skl_mat;
%% Removal of dead ends
st_inds = find(bwmorph3(skl,"endpoints")==1);
[st_subs(:,2),st_subs(:,1),st_subs(:,3)] = ind2sub(size(A),find(bwmorph3(skl,"endpoints")==1));
col = size(A,1);
pg = prod(size(A,1:2)); 
ops = [1 col pg col-1 col+1 pg+1 pg-1 pg+col pg-col pg+col+1 pg+col-1 pg-col+1 pg-col-1];%
t1 = st_inds + ops;
t2 = st_inds - ops;
t3 = [t1 t2];
t3(t3<= 0 | t3 > numel(lm)) = find(lm == 0,1); 
all_nbhs = ceil([st_inds t3.*ismembc(t3,skl_inds)]./pg);
t = all_nbhs(all_nbhs ~= 0,:);
% strt_locs = 1:size(A,1)*size(A,2);
% strt_fms = find(cellfun(@any, cellfun(@(x) ismembc(x,strt_locs), fam_all_ind,'UniformOutput',0))==1);
% strt_pts = stpts(ismembc(stpts, cell2mat(strt_fms)));


a = A(:,:,1);
B=bwdist(1-a);
B=medfilt2(B,[5 5]);
L=watershed(-B);
L=double(L).*double(a);
v = max(L,[],'all');
st_inds = st_inds(1:v);



a_m = zeros(length(skl_inds));

%% path finding  
j = 0;
for i = 1:length(st_inds)
    pth = zeros(1);
    i_p = st_inds(i);
    pth(1) = i_p;
    z = ceil(i_p/pg);
    k = 0;
    while any(i_p) == 1
        k = k+1;
        k;
          i_p = nonzeros(all_nbhs(ismembc(all_nbhs(:,1),i_p),2:end));
          zs = ceil(i_p/pg);
          i_p(zs<z) = [];
          z = z+1;
          msng = setdiff(i_p,pth);
          i_p = msng;
          pth = [pth; msng];
    end
    if z-ceil(pth(1)/pg)>450
        j = j+1;
        thru(j,1:3) = [i ceil(pth(1)/pg) z];
%         [pth_sbs(:,2),pth_sbs(:,1),pth_sbs(:,3)] = ind2sub(size(A),pth);
%         figure
%         scatter3(skl_sbs(:,1),skl_sbs(:,2),skl_sbs(:,3),'.')
%         clear pth_sbs
    end
    lngs(i,1:2) = [ceil(pth(1)/pg) z];
end

%% PNM based tort
dg_cons = zeros(size(cons,1),3);
n_t = array2table(cell2mat(families(:,1)),'VariableNames',{'X','Y','Z'});
a_m = triu(squareform(pdist(cell2mat(families(:,1)))));
for i = 1:size(cons,1)
  coords = cell2mat(families(cons(i,:)));
  if coords(3)<coords(6)
      dg_cons(i,1:2) = cons(i,:);
  else
      dg_cons(i,1:2) = [cons(i,2) cons(i,1)];
  end
  dg_cons(i,3) = a_m(cons(i,1),cons(i,2));
end
DG = digraph(dg_cons(:,1),dg_cons(:,2),dg_cons(:,3),n_t);
%% dg pt
% t = allpaths(DG,1,1316);
j = 0;
for i = 1:1%length(spts)
    pth = zeros(1);
    rtn = {spts(i)};
    j = 0;
    figure
    xlim([0 size(A,2)]); ylim([0 size(A,1)]); zlim([0 size(A,3)]);
    hold on
    while isempty(rtn) == 0
        pth = rtn{1};
        rtn(1) = [];
        i_p = pth(end);
        while any(i_p) == 1
              nxt = dg_cons(ismembc(dg_cons(:,1),i_p),2);
              if length(nxt)>1
                 n_pth = arrayfun(@(x) [i_p;x],nxt(2:end),'UniformOutput',false);
                 nxt(2:end) = [];
                 rtn = [rtn;n_pth];
              end
              msng = setdiff(nxt,pth);
              i_p = msng;
              pth = [pth; msng];
        end
        if any(fpts == pth(end)) == 1
            j = j+1;
            j
            sbs = cell2mat(families(pth,1));
            plot3(sbs(:,1),sbs(:,2),sbs(:,3),'Marker','.','Color',rand(1,3))
            pths(j,1) = {pth};
        end
    end
    space = zeros(size(A));
    space(cell2mat(families(pth,3))) = 1;
end
%% all paths (fast)
j = 0;
for i = 1:1%length(spts)
    pth = zeros(1);
    pth = spts(i);
    i_p = pth(end);
    while any(i_p) == 1
          nxt = dg_cons(ismembc(dg_cons(:,1),i_p),2);
          msng = setdiff(nxt,pth);
          i_p = msng;
          pth = [pth; msng];
    end
%     sbs = cell2mat(families(pth,1));
%     plot3(sbs(:,1),sbs(:,2),sbs(:,3),'Marker','.','Color',rand(1,3))
%     pths(j,1) = {pth};
    space = zeros(size(A));
    space(cell2mat(fam_all_ind(pth))) = 1;
end
% skl_p = bwskel(logical(imfill(space,'holes')));%,'MinBranchLength',50