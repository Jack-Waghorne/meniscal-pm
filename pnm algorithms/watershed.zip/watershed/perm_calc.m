function K = perm_calc(A,prs,cons,res,families)
%% use main ps
% L = bwconncomp(A); 
% % A = zeros(size(A));
% inds = cell2mat(L.PixelIdxList(2:end).');
% % A(inds) = 1;
% fms = find(cellfun(@any,cellfun(@(x) ismember(x,inds),families(:,3),'UniformOutput',0)));
% c_o = cons;
% cons = c_o;
% families = families(fms,:);
% cons = cons(any(ismember(cons(:,1:2),find(fms)),2),:);
% prs = prs(any(ismember(cons(:,1:2),find(fms)),2),:);
%% Conductance
mu = 0.0010016; % 20 = 0.0010016, 37 = 0.0006913
for i = 1:size(cons,1)
    ai = pi*(prs(i,1)*res)^2; prmi = 2*pi*(prs(i,1)*res); 
    aj = pi*(prs(i,2)*res)^2; prmj = 2*pi*(prs(i,2)*res); 
    at = pi*(prs(i,3)*res)^2; prmt = 2*pi*(prs(i,3)*res); 
    sfi = ai/prmi^2; sfj = aj/prmj^2; sft = at/prmt^2; 
    gi =  0.5*((sfi*ai^2)/mu); gj =  0.5*((sfj*aj^2)/(mu)); gt =  0.5*((sft*at^2)/(mu));
    cond_inv = 3*((prs(i,1)*res/gi)+(prs(i,2)*res/gj)+(prs(i,4)*res/gt));
    cons(i,4) = inv(cond_inv);
%     ci = (prs(i,1)*res)/((0.5*sfi/mu)*(inv(4*sfi)*(prs(i,1)*res)^2)^2);
%     cj = (prs(i,2)*res)/((0.5*sfi/mu)*(inv(4*sfi)*(prs(i,2)*res)^2)^2);
%     ct = (prs(i,4)*res)/((0.5*sfi/mu)*(inv(4*sfi)*(prs(i,3)*res)^2)^2);
%     cons(i,4) = inv(ci+cj+ct);
%     cons(i,4) = gt/(prs(i,4)*res);
%      cons(i,4) = (pi*(res*prs(i,3))^4)/(8*mu*prs(i,4)*res);
%    cons(i,4) = 1.342*(res*prs(i,3))^2- 0.913*res*prs(i,3) - 0.381; 
end
sm = zeros(size(families,1));
for i = 1:size(families,1)
    lst = [];
    thrts = cons(any(cons(:,1:2) == i,2),1:2);
    for j = 1:size(thrts,1)
        loc = all(cons(:,1:2) == thrts(j,:),2);
        Pj = setdiff(thrts(j,:),i);
        sm(i,Pj) = cons(loc,4);
        lst = [lst;cons(loc,4)];
    end
    sm(i,i) = -1*sum(lst);
end
% cons = cons(any(ismember(cons(:,1:2),find(fms)),2),:);
% fms_i = find(fms);
%% Solve equations
Pin = 2;
Pout = 1;
rots = {[1 3 2],[2 3 1],[1 2 3]};
[xg,yg,zg] = meshgrid(1:size(A,2),1:size(A,1),1:size(A,3));
for i = 1:3
    m_tmp = permute(A,rots{i});
    if i == 1
        s_inds = [reshape(squeeze(xg(:,1,:)),[],1) reshape(squeeze(yg(:,1,:)),[],1) reshape(squeeze(zg(:,1,:)),[],1)];
        f_inds = [reshape(squeeze(xg(:,size(A,2),:)),[],1) reshape(squeeze(yg(:,size(A,2),:)),[],1) reshape(squeeze(zg(:,size(A,2),:)),[],1)];   
    elseif i == 2
        s_inds = [reshape(squeeze(xg(1,:,:)),[],1) reshape(squeeze(yg(1,:,:)),[],1) reshape(squeeze(zg(1,:,:)),[],1)];
        f_inds = [reshape(squeeze(xg(size(A,1),:,:)),[],1) reshape(squeeze(yg(size(A,1),:,:)),[],1) reshape(squeeze(zg(size(A,1),:,:)),[],1)]; 
    elseif i == 3
        s_inds = [reshape(squeeze(xg(:,:,1)),[],1) reshape(squeeze(yg(:,:,1)),[],1) reshape(squeeze(zg(:,:,1)),[],1)];
        f_inds = [reshape(squeeze(xg(:,:,size(A,3))),[],1) reshape(squeeze(yg(:,:,size(A,3))),[],1) reshape(squeeze(zg(:,:,size(A,3))),[],1)];  
    end
    s_inds = sub2ind(size(A),s_inds(:,2),s_inds(:,1),s_inds(:,3)); 
    f_inds = sub2ind(size(A),f_inds(:,2),f_inds(:,1),f_inds(:,3)); 
    sm_tmp = sm;
    st_prs = find(cellfun(@any,cellfun(@(x) ismember(x,s_inds), families(:,3),'UniformOutput',0)));
    f_prs = find(cellfun(@any,cellfun(@(x) ismember(x,f_inds), families(:,3),'UniformOutput',0)));
%     ns = setdiff(fms,[st_prs;f_prs]);
%     ins = setdiff(1:size(families,1),ns).';
%     ct = cons(all(ismember(cons(:,1:2),ins),2),:);
ct = cons;
ins = 1:size(families,1);
    rmv = ones(size(sm_tmp));
    rmv([st_prs;f_prs],:) = 0;
    sm_tmp = sm_tmp.*rmv;
    I = find(eye(size(sm_tmp)));
    sm_tmp(I([st_prs;f_prs])) = 1;
    B = zeros(size(sm_tmp,1),1);
    B(st_prs) = Pin;
    B(f_prs) = Pout;
%     B(ns) = [];
%     sm_tmp(ns,:) = [];
%     sm_tmp(:,ns) = []; 
    pps = linsolve(sm_tmp,B);
%     ctrs = cell2mat(families(:,1));
%     scatter3(ctrs(ins,1),ctrs(ins,2),ctrs(ins,3),15,pps(:,1),'filled')
    pps(:,2) = ins;
    for j = 1:size(ct,1)
        Pi = pps(:,2) == ct(j,1);
        Pj = pps(:,2) == ct(j,2);
        zi = families{cons(j,1),1}(i);
        zj = families{cons(j,2),1}(i);
        [~,mm] = min([zi zj]);
        if mm == 1
            q(j,1) = cons(j,4)*(pps(Pi) - pps(Pj));
        else
            q(j,1) = cons(j,4)*(pps(Pj) - pps(Pi));
        end
    end
    K(i) = (mu*sum(q)*size(m_tmp,3)*res)/((Pin-Pout)*(size(m_tmp,1)*size(m_tmp,2)*res^2))
end
    K(4) = mean(K(1:3));
end
