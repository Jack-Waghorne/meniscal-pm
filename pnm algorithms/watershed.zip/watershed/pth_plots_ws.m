function plt = pth_plots()
A(A>1) = 1;
pth = cell2mat(tb(1).Path);
coords = table2array(G.Nodes(pth,:));
btw = diff(coords(:,3));
co_tmp = zeros(max(coords(:,3)),3);
co_tmp(:,3) = 1:max(coords(:,3));
% coords1(coords(:,3),1:2) = coords(:,1:2);
for i = 1:length(btw)
    dx = round(linspace(coords(i,1),coords(i+1,1),btw(i)+1));
    dy = round(linspace(coords(i,2),coords(i+1,2),btw(i)+1));
    dz = linspace(coords(i,3),coords(i+1,3),btw(i)+1);
    co_tmp(dz,:) = [dx.' dy.' dz.'];
end
coords = co_tmp;
chnl = zeros(size(A,1),size(A,2),size(A,3));
%% Path Volume
cmap = zeros(max(cell2mat(families(:,2)))+1,2);
cmap(:,1) = 0:max(cell2mat(families(:,2)));
cmap(:,2) = linspace(0,1,max(cell2mat(families(:,2)))+1);
figure()
for p = 1:length(pth)
%     colour = rand(1,3);
    rgb = cmap(families{pth(p),2},2);
    colour = [(0+rgb) 0 (1-rgb)];
    sphs = families{pth(p),1}(:,1:3);
    sphs = ismember(m_spheres(:,1:3),sphs,'rows');
    inds = unique(cell2mat(m_spheres_t(sphs,2)));
    [y,x,z] = ind2sub(size(A),inds);
    k = boundary(x,y,z);
    trisurf(k,x,y,z,'FaceColor',colour,'EdgeColor','none')
    hold on
    disp(['Families surfaced: ', num2str(p), '/', num2str(length(pth))])
%     xlim([0 164]); ylim([0 164]); zlim([1 2])
end
%% 2D Surfaces
sphs = cell2mat(families(pth,1));
inds = unique(cell2mat(m_spheres_t(ismember(m_spheres,sphs(:,1:4),'rows'),2)));
[row, col, lng] = ind2sub(size(A),inds);
if mt == 1
    for i = 1:size(A,3) 
        space = zeros(size(A,1),size(A,2));
        plane = [row(lng == i) col(lng == i) lng(lng == i)];
        plane = sub2ind(size(A),plane(:,2),plane(:,1));
        space(plane) = 1;
        chnl(:,:,i) = space;
        i
    end
elseif mt == 2
    cols = false(1,6);
    cols(1,1:3) = true;
    tmp = cellfun(@(x)x(:,cols),families(:,1),'UniformOutput',false);
    parfor i = 1:size(coords,1) 
        space = zeros(size(A,1),size(A,2));
        pt = coords(i,:);
        ind = sub2ind(size(A),pt(1),pt(2),pt(3));
        if A(pt(2),pt(1),pt(3)) == 1
            vds = find(A(:,:,i) == 0);
            [col, row] = ind2sub(size(A),vds);
            dist = pdist2([pt(1) pt(2)],[row, col]);
            [~,loc] = min(dist);
            pt = [row(loc) col(loc) i];
            ind = sub2ind(size(A),pt(1),pt(2),pt(3));
        end
        sph = find(cellfun(@any,cellfun(@(x)ismembc(x,ind),m_spheres_t(:,2),'UniformOutput',false))==1);
        if length(sph)>1
            sph = sph(1);
        end
        plane = m_spheres(sph,1:3);
        plane = cellfun(@any,cellfun(@(x)ismember(x,plane,'rows'),tmp,'UniformOutput',false));
        plane = families{plane}(:,1:4);
        inds = cell2mat(m_spheres_t(ismember(m_spheres,plane,'rows'),2));
        [row, col, lng] = ind2sub(size(A),inds);
        plane = [row(lng == pt(3)) col(lng == pt(3)) lng(lng == pt(3))];
        plane = sub2ind(size(A),plane(:,2),plane(:,1));
        space(plane) = 1;
        chnl(:,:,i) = space;
        i
    end
end
% for i=size(chnl,3)
% clf;
% imshow(chnl(:,:,i)); axis equal tight
% drawnow;
% pause(5);
% end
implay(chnl,4)
end 