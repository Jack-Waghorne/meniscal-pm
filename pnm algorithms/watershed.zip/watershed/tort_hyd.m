function thyd = tort_hyd(families,anlys,A)
%% build skel
conn = 26;
A = imfill(logical(A), 'holes');
skl = bwskel(A);
skl_inds = find(skl);
[y,x,z] = ind2sub(size(A),skl_inds);
skl_sbs = [x y z];
%% build graph
nbhs = find_nbhs(A,skl_inds,conn);
prs = nbhs.*skl(nbhs);
load('nbh_dists.mat');
if conn == 6
    dists = dists{1};
elseif conn == 18
    dists = dists{2};
elseif conn == 26
    dists = dists{3};
end
cons = cell(numel(skl_inds),1);
N = numel(skl_inds); %Total number of calculations 
ppm = ParforProgressStarter2('tort hyd', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
ppm = ParforProgress2('tort hyd',N);
for i = 1:numel(skl_inds)
    locs = prs(i,:)>skl_inds(i);
    cons{i,1} = [repmat(skl_inds(i),sum(locs),1) prs(i,locs).' dists(locs).'];
    ppm.increment(i)
end
delete(ppm)
cons = cell2mat(cons);
sns = string(cons(:,1));
fns = string(cons(:,2));
G = graph(sns,fns,cons(:,3),string(skl_inds));
%% path finding
anlys = anlys{3};
C = parallel.pool.Constant(families);
D = parallel.pool.Constant(anlys);
N = size(anlys, 1); %Total number of calculations 
ppm = ParforProgressStarter2('tort hyd', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
ppm = ParforProgress2('tort hyd',N);
parfor i = 1:size(anlys,1)
   spt = round(C.Value{D.Value{i,1},1});
   [~,si] = pdist2(skl_sbs,spt,'euclidean','Smallest',1);
   fpt =  round(C.Value{D.Value{i,2},1});
   [~,fi] = pdist2(skl_sbs,fpt,'euclidean','Smallest',1);
   [~,L] = shortestpath(G,si,fi);
   dist = pdist2(spt,fpt);
   thyd(i,1) = L/dist;
   ppm.increment(i)
end
delete(ppm)
%% anistropy
subplot(2,2,3)
histogram(cell2mat(anlys(:,5)),25);
title('Tortuosity Distribution Plot')
xlabel('Tortuosity')
ylabel('Frequency')
ani = [cell2mat(anlys(:,5)) round(cell2mat(anlys(:,6)))];
k = 0;
for j = 0:360
    k = k+1;
    loc = ani(:,2) == j;
    mag = mean(ani(loc,1));
    tota(k,1) = j;
    tota(k,2) = mag;
end
tota(isnan(tota(:,2)),:) = [];
subplot(2,2,4)
polarplot(deg2rad(tota(:,1)),tota(:,2))
title('Polar Tortuosity Plot')
thetatickformat('degrees')
rlim([min(tota(:,2)) max(tota(:,2))])
end