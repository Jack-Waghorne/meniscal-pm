st_prs = 1;
f_prs = 4;
prs = zeros(4,6);
cons = [1 2; 2 3 ;3 4];
rp = 10; rt = 5; dist = 100;
mu = 0.0010016; % 20 = 0.0010016, 37 = 0.0006913
for i = 1:size(cons,1)
    ai = pi*(rp)^2; prmi = 2*pi*(rp); 
    aj = pi*(rp)^2; prmj = 2*pi*(rp); 
    at = pi*(rt)^2; prmt = 2*pi*(rt); 
    sfi = ai/prmi^2; sfj = aj/prmj^2; sft = at/prmt^2; 
    gi =  0.5*((sfi*ai^2)/(mu)); gj =  0.5*((sfj*aj^2)/(mu)); gt =  0.5*((sft*at^2)/(mu));
    cond_inv = (rp/gi)+(rp/gj)+(dist/gt);
    cons(i,4) = inv(cond_inv);
end
sm = zeros(4);
for i = 1:4
    lst = [];
    thrts = cons(any(cons(:,1:2) == i,2),1:2);
    Pi = i;
    for j = 1:size(thrts,1)
        loc = all(cons(:,1:2) == thrts(j,:),2);
        Pj = setdiff(thrts(j,:),i);
        sm(i,Pj) = cons(loc,4);
        lst = [lst;cons(loc,4)];
    end
    sm(i,i) = -1*sum(lst);
end
Pin = 2;
Pout = 1;
rmv = ones(size(sm));
rmv([st_prs;f_prs],:) = 0;
% rmv(:,[st_prs;f_prs]) = 0;
sm = sm.*rmv;
I = find(eye(size(sm)));
sm(I([st_prs;f_prs])) = 1;
B = zeros(size(sm,1),1);
B(st_prs) = Pin;
B(f_prs) = Pout;
linsolve(sm,B);