function [s_prs, f_prs] = sfp(A,families)
rots = {[1 3 2],[2 3 1],[1 2 3]};
[xg,yg,zg] = meshgrid(1:size(A,2),1:size(A,1),1:size(A,3));
for i = 3:3
    m_tmp = permute(A,rots{i});
    if i == 1
        s_inds = [reshape(squeeze(xg(:,1,:)),[],1) reshape(squeeze(yg(:,1,:)),[],1) reshape(squeeze(zg(:,1,:)),[],1)];
        f_inds = [reshape(squeeze(xg(:,size(A,2),:)),[],1) reshape(squeeze(yg(:,size(A,2),:)),[],1) reshape(squeeze(zg(:,size(A,2),:)),[],1)];   
    elseif i == 2
        s_inds = [reshape(squeeze(xg(1,:,:)),[],1) reshape(squeeze(yg(1,:,:)),[],1) reshape(squeeze(zg(1,:,:)),[],1)];
        f_inds = [reshape(squeeze(xg(size(A,1),:,:)),[],1) reshape(squeeze(yg(size(A,1),:,:)),[],1) reshape(squeeze(zg(size(A,1),:,:)),[],1)]; 
    elseif i == 3
        s_inds = [reshape(squeeze(xg(:,:,1)),[],1) reshape(squeeze(yg(:,:,1)),[],1) reshape(squeeze(zg(:,:,1)),[],1)];
        f_inds = [reshape(squeeze(xg(:,:,size(A,3))),[],1) reshape(squeeze(yg(:,:,size(A,3))),[],1) reshape(squeeze(zg(:,:,size(A,3))),[],1)];  
    end
   s_inds = sub2ind(size(A),s_inds(:,2),s_inds(:,1),s_inds(:,3)); 
   f_inds = sub2ind(size(A),f_inds(:,2),f_inds(:,1),f_inds(:,3)); 
   s_prs{i,1} = find(cellfun(@any,cellfun(@(x) ismember(x,s_inds), families(:,3),'UniformOutput',0)));
   f_prs{i,1} = find(cellfun(@any,cellfun(@(x) ismember(x,f_inds), families(:,3),'UniformOutput',0)));
end
end