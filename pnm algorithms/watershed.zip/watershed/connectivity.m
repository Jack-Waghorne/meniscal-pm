function [cons,con_inds,families] = connectivity(lm,rl,conn,families)
con_m = lm(find_nbhs(lm,rl,conn));
k=0;
cons = [];
for i = 1:size(families,1)   
    locs = find(any(con_m ==i,2));
    nbhs = double(con_m(locs,:));
    con_u = nonzeros(unique(nbhs));
    con_u(con_u<=i) = [];
    prs = [repmat(i,length(con_u),1) con_u];
    for j = 1:numel(con_u)
        k = k+1;
        con_inds{k,1} = rl(locs(any(nbhs == i,2) & any(nbhs == con_u(j),2)));
        prs(j,3) = pdist2(families{i,1},families{con_u(j),1});
    end
    cons = [cons;prs];
end
coords = histcounts(cons(:,1:2),1:size(families,1)+1).';
families(:,4) = num2cell(coords);
subplot(2,2,2)
histogram(cell2mat(families(:,4)),max(cell2mat(families(:,4)))); 
xlabel('Coordination Number'); ylabel('Frequency');  title('Coordination Number Distribution');
end