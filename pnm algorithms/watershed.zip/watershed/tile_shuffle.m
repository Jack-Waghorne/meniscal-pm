clear
clc
% close all
tic
%% Segmentation
load('C:\Users\jackw\Documents\AI Imaging Project\MATLAB Scripts\Masters_project_scripts\datasets\VOI(2)_uncropped.mat')
set = 2;
A = imstore(:,:,:);
A = circ_crop(A,set); %Circular for dataset
A = A(:,:,:);
A(A>1) = 1;
centre = [185 185];
radii = 182;
% viscircles(centre,radii,'color', 'b','lineWidth', 0.5);
xp = [centre(1)+radii*cos(deg2rad(45)) centre(1)-radii*cos(deg2rad(45)) centre(1)-radii*cos(deg2rad(45)) centre(1)+radii*cos(deg2rad(45)) centre(1)+radii*cos(deg2rad(45))];
yp = [centre(2)+radii*sin(deg2rad(45)) centre(2)+radii*sin(deg2rad(45)) centre(2)-radii*sin(deg2rad(45)) centre(2)-radii*sin(deg2rad(45)) centre(2)+radii*sin(deg2rad(45))];
% line(xp(:), yp(:), 'color', 'r','lineWidth', 2);
n = 1;
xpu = unique(xp);
ypu = unique(yp);
xps = linspace(xpu(1),xpu(2),(n+1));
yps = linspace(ypu(1),ypu(2),(n+1));
xps(length(xps)) = []; yps(length(yps)) = [];
[i,j] = ndgrid(xps, yps);
coords = [i(:),j(:)];
k = 0;
for i = 1:size(A,3)
    im = A(:,:,i);
    for j = 1:size(coords,1)
        k=k+1;
        ims(:,:,k) = imcrop(im,[coords(j,1) coords(j,2) (xpu(2)-xpu(1))/n+1 (ypu(2)-ypu(1))/n+1]);
    end
end
nm = zeros(size(ims));
r = randperm(size(ims,3));
nm = ims(:,:,r);
nm = reshape(nm,n*size(ims,1),n*size(ims,2),size(A,3));
A = nm;
%% Load in Data
A = 1-A;
A = bwmorph3(A,"majority");
L = bwconncomp(A); 
szs = cellfun(@length,L.PixelIdxList);
[~,idx] = max(szs);
A = zeros(size(A));
A(L.PixelIdxList{idx}) = 1;
% A = 1-A;
res = 6.25; %Image resolution
[LM,families,RL] = wsgt(A,res);
families = table2cell(families);
disp('Segmentation Complete')
toc
[cons,families] = ws_con(LM,families);
disp('Connectivity Analysis Complete')
toc
G = setupgraph_ws(families,cons);
disp('Graph Creation Complete')
toc
[spts, fpts] = makepts_ws(families,A);
 disp('Start / Finish Points Created')
toc
anlys = pth_prms_ws(G,spts,fpts);
disp('Path Parameters Found')
toc