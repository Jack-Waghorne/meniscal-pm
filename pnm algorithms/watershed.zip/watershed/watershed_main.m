clear
clc
% close all
tic
%% Load in Data
load('');
A = imstore;%(1:50,1:50,1:50)
%% initalise v1ariabls + conn
% set = 4;
res = 6.25; %Image resolution
conn = 26; %6 26
%% Preprocessing
% A = circ_crop(A,set); %Circular for dataset
A = prepcs(A,conn);
%% Analysis
[lm,rl,families] = wsgt(A,res);
disp('Segmentation Complete')
toc
[cons,con_inds,families] = connectivity(lm,rl,conn,families);
disp('Connectivity Analysis Complete')
toc
prs = throat_analysis(lm,families,cons,con_inds,res);
disp('PNM Complete')
toc
% K = perm_calc(A,prs,cons,res,families);
% disp('perm calculation Complete')
% toc
% n_t = array2table(cell2mat(families(:,1)),"VariableNames",{'X','Y','Z'});
% G = graph(cons(:,1),cons(:,2),cons(:,3),n_t);
% disp('Graph Creation Complete')
% toc
% [s_prs, f_prs] = sfp(A,families);
% anlys = tort_pnm(G,s_prs,f_prs);
% thyd = tort_hyd(families,anlys,A);
% % tv = tort_voxel(A,families,anlys);
% 
% tb = [mean(A,'all')*100 size(families,1) size(cons,1) mean(cell2mat(families(:,2)))*res...
%     mean(2*prs(:,3))*res mean(prs(:,4))*res mean(cell2mat(families(:,4))) mean(thyd)];

