function prs = throat_analysis(lm,families,cons,con_inds,res)
prs = zeros(size(cons,1),4);
for i = 1:size(cons,1)
%     v1 = families{cons(i,1),1};
%     v2 = families{cons(i,2),1};
%     v = (v2 - v1);
%     space = zeros(size(lm));
%     space(con_inds{i}) = 1;
%     im=((regionprops3(space,"BoundingBox",'Centroid')));
%     bbx = max(im.(2)(4:6));
%     [P,Q] = meshgrid(-bbx:bbx);
%     ct = im.(1);
%     stp = ceil(pdist2(v1,v2))*1;
%     x = linspace(ct(1)-v(1)/2,ct(1)+v(1)/2,stp);
%     y = linspace(ct(2)-v(2)/2,ct(2)+v(2)/2,stp);
%     z = linspace(ct(3)-v(3)/2,ct(3)+v(3)/2,stp);
%     w = null(v);
%     trns = zeros([size(P) numel(z)]);
%     for j = 1:numel(z)
%         X = round(x(j)+w(1,1)*P+w(1,2)*Q); % Compute the corresponding cartesian coordinates
%         Y = round(y(j)+w(2,1)*P+w(2,2)*Q); %   using the two vectors in w
%         Z = round(z(j)+w(3,1)*P+w(3,2)*Q);
% %         surf(X,Y,Z,'FaceColor',[0 0.4470 0.7410])
%         dsq = (X<=0 | X>size(lm,2) | Y<=0 | Y>size(lm,1) | Z<=0 | Z>size(lm,3));
%         X(dsq) = 1;
%         Y(dsq) = 1;
%         Z(dsq) = 1;
%         inds = sub2ind(size(space),Y,X,Z);
%         vals = space(inds);
%         vals(dsq) = 0;
%         trns(:,:,j) = vals;
%     end  
%     if unique(trns) == 0
%         trns = space;
%     end
%     [i_sbs(:,2),i_sbs(:,1),i_sbs(:,3)] = ind2sub(size(trns),find(trns == 1));
%     im2 = zeros(size(trns,1));
%     idx = sub2ind(size(trns),i_sbs(:,1),i_sbs(:,2));
%     im2(idx) = 1;
%     sa = sum(im2,'all');
    sa = numel(con_inds{i});
    rad = sqrt(sa/pi);
    clear i_sbs
    prs(i,:) = [families{cons(i,1),2}/2 families{cons(i,2),2}/2 rad...
        (cons(i,3))];%-prs(i,1)-prs(i,2)
    if rem(i,100) == 0
        disp(['Throat analysis: ', num2str(i/size(cons,1)*100),'%'])
    end
end 
prs(prs(:,4)<0,4) = cons(prs(:,4)<0,3)/3;
impos = (sum(prs(:,1)<prs(:,3) | prs(:,2)<prs(:,3))/size(prs,1))*100;
imprs = prs(prs(:,1)<prs(:,3) | prs(:,2)<prs(:,3),:);
disp([num2str(impos),'% of the throats are impossible'])
%% find minimum sizes
% rads = cell2mat(families(:,2))/2;
% for i = 1:size(families,1)
%     sz = max(prs(any(cons == i,2),3));
%     rads(i,2) = sz;
% end
% locs = find(rads(:,1) - rads(:,2)<0);
% rads(:,3) = rads(:,1) - rads(:,2);
% rads(locs,1) = rads(locs,2);
% rads(locs,3) = 0;
% coords = [cell2mat(families(:,1)) rads(:,1) (1:size(families,1)).'];
% rmax = coords(:,4);
% for i = 1:size(families,1)
%     x = coords(i,1); y = coords(i,2); z = coords(i,3); r = coords(i,4);
%     in = x-coords(i,4)-rmax<coords(:,1)&coords(:,1)<x+coords(i,4)+rmax...
%     &y-coords(i,4)-rmax<coords(:,2)&coords(:,2)<y+coords(i,4)+rmax...
%     &z-coords(i,4)-rmax<coords(:,3)&coords(:,3)<z+coords(i,4)+rmax;
%     in = coords(in,:);
%     in(in(:,5) == i,:) = [];
%     dist = (pdist2([x y z],in(:,1:3))).'; 
%     in(:,6) = dist;
%     in(:,4) = in(:,4) + r;
%     in(in(:,4)<in(:,6),:) = [];
%     in(:,4) = in(:,4) - r; 
%     c_chk = [repmat(i,size(in,1),1) in(:,5)];
%     ism = ismember(c_chk,cons(:,1:2),'rows');
%     in(ism,8) = prs(ismember(cons(:,1:2),c_chk,'rows'),3);
%     in(:,7) = sqrt(2*sqrt((in(:,8).^2-in(:,4).^2).*(in(:,8).^2-r^2))-2.*in(:,8).^2+in(:,4).^2+r^2)-in(:,6);
%     in(in(:,7)<0,:) = [];
%     flt_i = rads(i,3);
%     flt_j = rads([in(:,5)],3);
%     while isempty(in) == 0
%         [dist,loc] = min(in(:,7));
%         calc = [dist flt_i flt_j(loc)];
%         if dist/2<min(calc(2:3))
%             flt_i = flt_i - dist/2;
%             flt_j(loc) = flt_j(loc) - dist/2;
%         elseif dist>calc(2)+calc(3)
%             flt_i = 0;
%             flt_j(loc) = 0;
%         else
%             [~,ml] = min(calc(2:3));
%             dist = dist - min(calc(2:3));
%             if ml == 3
%                 flt_i = 0;
%                 flt_j(loc) = flt_j(loc) - dist;
%             elseif ml == 2
%                flt_j(loc) = 0;
%                flt_i  = flt_i - dist;
%             end
%         end
%         lst = in(loc,5); 
%         rads(lst,[1 3]) = [rads(lst,1)-(rads(lst,3)-flt_j(loc)) flt_j(loc)];
%         in(loc,:) = [];
% 
%         r = rads(i,1)-(rads(i,3)-flt_i);
%         rads(i,[1 3]) = [r flt_i];
%         in(:,7) = sqrt(2*sqrt((in(:,8).^2-in(:,4).^2).*(in(:,8).^2-r^2))-2.*in(:,8).^2+in(:,4).^2+r^2)-in(:,6);
%         in(in(:,7)<0,:) = [];
%     end
% end
% for i = 1:size(families,1)
%     prs(cons(:,1:2) == i) = rads(i,1);
% end
%% Render
% figure
% for i = 1:size(families,1)
%     i
%     coords = families{i,1};
%     x = coords(1,1); y = coords(1,2); z = coords(1,3);
%     thrts = cons(any(cons(:,1) == i,2),2);
%     locs = find(any(cons(:,1) == i,2) == 1);
%    for j = 1:numel(thrts)
% %         [m,n,p]=cylinder2P(min(prs(:,3)),10,[x y z],families{thrts(j),1});
%         [m,n,p]=cylinder2P((prs(locs(j),3)),30,[x y z],families{thrts(j),1});
%         surf(m,n,p,ones(size(p))*prs(locs(j),3)*6.25,'EdgeColor', 'none','FaceAlpha',1);%FaceColor',[0 .447 0.741]
%         hold on
%     end
% end
% colormap winter
% caxis([min(prs(:,3))*6.25 max(prs(:,3))*6.25]);
% freezeColors
% freezeColors(jicolorbar);
% [a, b, c] = sphere(20);
% for i = 1:size(families,1)
%     i
%     coords = families{i,1};
%     x = coords(1,1); y = coords(1,2); z = coords(1,3); r = rads(i,1);
%     surf(a.*r+x,b.*r+y,c.*r+z,ones(size(c))*rads(i,2)*6.25,'EdgeColor', 'none','FaceAlpha',1);%,'FaceColor',[0.466 0.674 0.188],
%     hold on
% end
% colormap parula
% caxis([min(szs)*6.25 max(szs)*6.25]);
% h = colorbar('Location','eastoutside');
% ylabel(h, 'Radius (\mum)','FontSize',10);
% set(gca,'XTick',[],'YTick',[],'ZTick',[]);
% set(gca,'XColor',[1 1 1],'YColor',[1 1 1],'ZColor',[1 1 1],'TickDir','out')
% camlight('left','local');
% daspect([1 1 1])
% lighting gouraud
%% create model
% model = zeros(size(lm));
% set = 3;
% [px,py,pz] = meshgrid(1:size(lm,2), 1:size(lm,1), 1:size(lm,3));
% C = parallel.pool.Constant(families);
% D = parallel.pool.Constant(cons);
% E = parallel.pool.Constant(prs);
% N = size(coords, 1); %Total number of calculations 
% ppm = ParforProgressStarter2('mkpts', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
% ppm = ParforProgress2('mkpts',N); 
% parfor i = 1:size(rads,1)
%     tt = [];
%     coords = C.Value{i,1};
%     x = coords(1); y = coords(2); z = coords(3); r = rads(i,1);
%     inds = find((px-x).^2 + (py-y).^2 + (pz-z).^2 <=r*r);
%     sph_inds{i,1} = inds;
%     thrts = D.Value(any(D.Value(:,1) == i,2),2);
%     locs = find(any(D.Value(:,1) == i,2) == 1);
%    for j = 1:numel(thrts)
%         [m,n,p]=cylinder2P(E.Value(locs(j),3),10,[x y z],C.Value{thrts(j),1});
%         m = reshape(m,[],1);
%         n = reshape(n,[],1);
%         p = reshape(p,[],1);
%         shp = alphaShape(m,n,p,inf);
%         tf = find(inShape(shp,px,py,pz));
%         tt = [tt;tf];
%    end
%     t_inds{i,1} = tt;
%     ppm.increment(i);
% end
% delete(ppm)
% model([cell2mat(sph_inds);cell2mat(t_inds)]) = 1;
% cyl = crt_cyl(lm,set);
% smp_model = cyl - model;
% smp_model(smp_model<0) = 0;
% % % p = isosurface(smp_model);
% % % p1 = patch('Faces',p.faces,'Vertices',p.vertices,'FaceColor',[0.8 .8 .8],'EdgeColor','none','FaceAlpha',1);
% % % isonormals(smp_model,p1)
% % % p = isocaps(smp_model);
% % % p2 = patch('Faces',p.faces,'Vertices',p.vertices,'FaceColor',[0.8 .8 .8],'EdgeColor','none','FaceAlpha',1);
% % % isonormals(smp_model,p2)
%% distance check
%  dists = triu(squareform(pdist(cell2mat(families(:,1)))));
%  rads = cell2mat(families(:,2))/2;
%  r_m = zeros(size(families,1));
%  for i = 1:size(families,1)
%     r_m(i,i+1:end) = rads(i) + rads(i+1:end);
%  end
%  cllsn = sum(any(r_m>dists));
%  disp([num2str(100*cllsn/size(families,1)),'% of the spheres are overlapped'])
end