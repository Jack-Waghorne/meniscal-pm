function A = prepcs(A,conn)
A = 1-A;
A = bwmorph3(A,"majority");
A = imopen(A,strel("sphere",2));
A = imclose(A,strel("sphere",2));
% L = bwconncomp(A,conn); 
% % A(cell2mat(L.PixelIdxList(2:end).')) = 0;
% szs = cellfun(@length,L.PixelIdxList);
% idx = szs<20;
% A(cell2mat(L.PixelIdxList(2:end).')) = 0;
% A = bwmorph3(A,"majority");
% L = bwconncomp(A,conn); 
% szs = cellfun(@length,L.PixelIdxList);
% [~,idx] = max(szs);
% A = zeros(size(A));
% A(L.PixelIdxList{idx}) = 1;
end
