function anlys = tort_anlys(families,G,A)
s_inds = (1:prod(size(A,1:2))).'; 
f_inds = (numel(A)-prod(size(A,1:2))+1:numel(A)).';
s_prs = find(cellfun(@any,cellfun(@(x) ismember(x,s_inds), families(:,3),'UniformOutput',0)));
f_prs = find(cellfun(@any,cellfun(@(x) ismember(x,f_inds), families(:,3),'UniformOutput',0)));
[v_all(:,2),v_all(:,1),v_all(:,3)] = ind2sub(size(A),find(A));
%% Build skel
B = imfill(A, 'holes');
skl = bwskel(logical(B));%,'MinBranchLength',50
L = bwconncomp(skl);
szs = cellfun(@length,L.PixelIdxList);
[~,idx] = max(szs);
skl = zeros(size(skl));
skl(L.PixelIdxList{idx}) = 1;
skl_inds = find(skl == 1);
%% Removal of dead ends
bnch_e = find(bwmorph3(skl,"endpoints")==1);
bnch_b = find(bwmorph3(skl,"branchpoints")==1);
% b_prs = find(cellfun(@any,cellfun(@(x) ismember(x,bnch_b), families(:,3),'UniformOutput',0)));
s_inds = bnch_e(ismember(bnch_e,cell2mat(families([s_prs],3))));
f_inds = bnch_e(ismember(bnch_e,cell2mat(families([f_prs],3))));
bnch_cut = setdiff(bnch_e,[s_inds;f_inds]);
% [st_subs(:,2),st_subs(:,1),st_subs(:,3)] = ind2sub(size(A),lst);
col = size(A,1);
pg = prod(size(A,1:2)); 
ops = [1 col pg col-1 col+1 pg+1 pg-1 pg+col pg-col pg+col+1 pg+col-1 pg-col+1 pg-col-1];%
t1 = skl_inds + ops;
t2 = skl_inds - ops;
t3 = [skl_inds t1 t2];
t3(t3<= 0 | t3 > numel(A)) = find(A == 0,1); 
all_nbhs = t3.*ismembc(t3,skl_inds);
%% clear from skel
lst = [];
for i = 1:numel(bnch_cut)
    i
    nbhs = bnch_cut(i);
    lst = [lst;nbhs];
    while numel(nbhs) <= 1 && isempty(nbhs) == 0
        nbhs = nonzeros(all_nbhs(ismembc(all_nbhs(:,1),nbhs),2:end));
        nbhs = setdiff(nbhs,lst);
        if numel(nbhs) <= 1
            lst = [lst;nbhs];
        end
    end
    tmp = find(cellfun(@any,cellfun(@(x) ismember(x,lst(end)), families(:,3),'UniformOutput',0)));
    if isempty(tmp) == 1
        [tmp(1,2),tmp(1,1),tmp(1,3)] = ind2sub(size(A),lst(end));
       [~,I] = pdist2(v_all,tmp,'euclidean','Smallest',1);
       b_prs(i,1) = sub2ind(size(A),v_all(I,2),v_all(I,1),v_all(I,3));
    else
        b_prs(i,1) = find(cellfun(@any,cellfun(@(x) ismember(x,lst(end)), families(:,3),'UniformOutput',0)));
    end
end
%% remove pores
rmv_prs = find(cellfun(@any,cellfun(@(x) ismember(x,lst), families(:,3),'UniformOutput',0)));
rmv_prs = setdiff(rmv_prs,b_prs);
A_tmp = A;
A_tmp(cell2mat(families(rmv_prs,3))) = 0;
L = bwconncomp(A_tmp);
lst = cell2mat(L.PixelIdxList(2:end).');
lst = find(cellfun(@any,cellfun(@(x) ismember(x,lst), families(:,3),'UniformOutput',0)));
lst = setdiff(lst,b_prs);
rmv_prs = [rmv_prs;lst];
%%
G = rmnode(G,rmv_prs);
lst = [];
locs = 1;
N = degree(G);
while isempty(locs) == 0
    G_tmp = G;
    G_tmp = rmnode(G_tmp,lst);
    N = degree(G_tmp);
    locs = find(N == 1);
    locs = setdiff(locs,[s_prs;f_prs]);
    lst = [lst;locs];
end