clear
clc
% close all
tic
%% Load in Data
load('C2.mat');
A = imstore;%(:,:,1:5)
%% initalise variabls + conn
% set = 3;
conn = 26;
res = 5.35; %Image resolution
%% Preprocessing
% A = circ_crop(A,set);
A = prepcs(A,conn);
%% Maximum Inscribed spheres
[m_spheres,con_s] = mba_mis(A); %Function where majority of computation comes from
disp('Max-Inscribed Spheres Complete')
toc    
%% MBA
[m_spheres] = mba(A,m_spheres,con_s);
disp('MBA Complete')
toc
%% Label matrix fill
[families,lm] = fill_map(A,m_spheres);
disp('Label Matrix formed')
toc
%% Connectivity Analysis
[cons,con_inds,families] = con_mba(lm,families,conn);
disp('Connectivity analysis complete')
toc
%% PNM
prs = throat_analysis(lm,families,cons,con_inds,res);
disp('pnm complete')
toc
%% sfp
% [s_prs, f_prs] = sfp(A,families);
% %% perm
%  K = perm_calc(A,prs,cons,res,families,s_prs,f_prs);
% disp('perm calculation Complete')
% toc
% %% make graph
% n_t = array2table(cell2mat(families(:,1)),"VariableNames",{'X','Y','Z'});
% G = graph(cons(:,1),cons(:,2),cons(:,3),n_t);
% disp('Graph Creation Complete')
% toc
% %% tortuosity 
% anlys = tort_pnm(G,s_prs,f_prs);
% thyd = tort_hyd(families,anlys,A);
% tv = tort_voxel(A,families,anlys);

