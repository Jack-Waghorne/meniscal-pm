function [cons,con_inds,families] = con_mba(lm,families,conn)
cons = [];
k = 0;
for i = 1:size(families,1)
    space = zeros(size(lm));
    space(families{i,3}) = 1;
    inds = find(bwperim(space));
    nbhs = find_nbhs(lm,inds,conn);
    nbhs = double(lm(nbhs));
    con_u = nonzeros(unique(nbhs));
    con_u(con_u<=i) = [];
    prs = [repmat(i,length(con_u),1) con_u];
    for j = 1:numel(con_u)
        k = k+1;
        con_inds{k,1} = inds(any(nbhs == con_u(j),2));
        prs(j,3) = pdist2(families{i,1},families{con_u(j),1});
    end
    cons = [cons; prs];
    if rem(i,100) == 0
        disp(['Connecitivty analysis: ', num2str(i/size(families,1)*100),'%'])
    end
end
lm(cell2mat(con_inds)) = 0;
families=table2cell(regionprops3(lm,'EquivDiameter','Centroid','VoxelIdxList'));
szs = cell2mat(cellfun(@numel,families(:,3),'UniformOutput',0));
if any(szs == 0)
    error
end
coords = histcounts(cons(:,1:2),1:size(families,1)+1).';
families(:,4) = num2cell(coords);
%% watershed version
% space = zeros(size(lm));
% space([families{i,3};families{con_u(j),3}]) = 1;
% szs = cell2mat(cellfun(@numel,families(:,3),'UniformOutput',0));
% tmp = [szs(i);szs(con_u(j))];
% [~,idx] = max(tmp);
% locs = any(nbhs == con_u(j),2);
% nbhs_i = find_nbhs(lm,families{i,3},conn);
% nbhs_i = nbhs_i(locs,:);
% nbhs_i(nbhs(locs,:) == 1);
% 
% [yi,xi,zi] = ind2sub(size(lm),families{i,3});
% bi = boundary(xi,yi,zi,1);
% binds = ind2sub(size(lm),)
% 
% i_inds = find(bwperim(space));
% nbhs_i = find_nbhs(lm,i_inds,conn);
% nbhs_i = lm(nbhs_i);
%% plot
% subplot(2,2,2);
% histogram(cell2mat(families(:,4)),max(cell2mat(families(:,4)))); xlabel('Coordination Number'); ylabel('Frequency');  title('Coordination Number Distribution');
end