function anlys = tort_pnm(G,s_prs,f_prs)
for i = 3:3
    spts = s_prs{i};
    fpts = f_prs{i};
    allcombs  = nchoosek([spts; fpts],2);
    allcombs(all(ismember(allcombs,spts),2),:) = [];
    allcombs(all(ismember(allcombs,fpts),2),:) = [];
    tb = struct("StartPoint",[],"FinishPoint",[],"Distance",[],"Length",[],"Tortuosity",[],"Orientation",[],"Path",[]);
    C = parallel.pool.Constant(allcombs);
    N = size(allcombs, 1); %Total number of calculations 
    ppm = ParforProgressStarter2('pth prms', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
    ppm = ParforProgress2('pth prms',N);
    parfor j = 1:size(allcombs,1)
        p1 = table2array(G.Nodes(C.Value(j,1),:));
        p2 = table2array(G.Nodes(C.Value(j,2),:));
        [P,L] = shortestpath(G,C.Value(j,1),C.Value(j,2));
        tb(j).StartPoint = C.Value(j,1);
        tb(j).FinishPoint = C.Value(j,2);
        tb(j).Distance = pdist2(p1,p2);
        tb(j).Length = L;
        tb(j).Tortuosity = L/pdist2(p1,p2);
        tb(j).Orientation = wrapTo360(rad2deg(atan2(p2(2)-p1(2),p2(1)-p1(1))));
        tb(j).Path = P;
        ppm.increment(j);
    %     if i == 1
    %         figure()
            h = plot(G,'XData',G.Nodes.X,'YData',G.Nodes.Y,'ZData',G.Nodes.Z);%,'MarkerSize',1,'LineWidth',0.1
    %     end
    %     highlight(h,P,'EdgeColor',rand(1,3),'LineWidth',2);
    %     hold on
    end
    delete(ppm)
    %% Plotting
    an_tmp = struct2cell(tb);
    if length(size(an_tmp)) > 2
        an_tmp = squeeze(an_tmp);
    end
    an_tmp = an_tmp.';
    an_tmp(isinf(cell2mat(an_tmp(:,5)))|isnan(cell2mat(an_tmp(:,5))),:) = [];
    anlys{i,1} = an_tmp;
end
% subplot(2,2,3)
% histogram(cell2mat(anlys{3}(:,5)),25);
% title('Tortuosity Distribution Plot')
% xlabel('Tortuosity')
% ylabel('Frequency')
% ani = [cell2mat(anlys{3}(:,5)) round(cell2mat(anlys{3}(:,6)))];
% k = 0;
% for j = 0:360
%     k = k+1;
%     loc = ani(:,2) == j;
%     mag = mean(ani(loc,1));
%     tota(k,1) = j;
%     tota(k,2) = mag;
% end
% tota(isnan(tota(:,2)),:) = [];
% subplot(2,2,4)
% polarplot(deg2rad(tota(:,1)),tota(:,2))
% title('Polar Tortuosity Plot')
% thetatickformat('degrees')
% rlim([min(tota(:,2)) max(tota(:,2))])
end