function [cons,con_inds,families] = con_an(lm,families,ops)
cons = [];
k = 0;
lm_tmp = zeros(size(lm));
for i = 1:size(families,1)
%     i;
    inds_i = families{i,3};
    t1 = inds_i + ops;
    t2 = inds_i - ops;
    t3 = [t1 t2];
    t3(t3<= 0 | t3 > numel(lm)) = find(lm == 0,1);
    nbhs = lm(t3);
    con_u = nonzeros(unique(nbhs));
    con_u(con_u<=i) = [];
    prs = [repmat(i,length(con_u),1) con_u];
    if isempty(con_u) == 0
        prs(:,3) = pdist2(families{i,1},cell2mat(families(con_u,1))).';
    end
    for j = 1:numel(con_u)
        k = k+1;
        con_inds{k,1} = inds_i(any(nbhs == con_u(j),2));
        families{i,3} = families{i,3}(logical(1-ismember(families{i,3},con_inds{k,1})));
% %         [i_sbs(:,2),i_sbs(:,1),i_sbs(:,3)] = ind2sub(size(lm_fld),families{i,3});
% %           l = boundary([i_sbs(:,1),i_sbs(:,2),i_sbs(:,3)],1); 
% %         [j_sbs(:,2),j_sbs(:,1),j_sbs(:,3)] = ind2sub(size(lm_fld),families{con_u(j),3});
% %           m = boundary([j_sbs(:,1),j_sbs(:,2),j_sbs(:,3)],1); 
% %         [k_sbs(:,2),k_sbs(:,1),k_sbs(:,3)] = ind2sub(size(lm_fld),con_inds{k,1});
% %           trisurf(l,i_sbs(:,2),i_sbs(:,1),i_sbs(:,3),'FaceColor','r','FaceAlpha',0.25) 
% %           hold on
% %           trisurf(m,j_sbs(:,2),j_sbs(:,1),j_sbs(:,3),'FaceColor','b','FaceAlpha',0.25) 
% %           clear i_sbs j_sbs k_sbs
%         scatter3(i_sbs(:,1),i_sbs(:,2),i_sbs(:,3),'filled')
%         hold on
%         scatter3(j_sbs(:,1),j_sbs(:,2),j_sbs(:,3),'filled')
%         scatter3(k_sbs(:,1),k_sbs(:,2),k_sbs(:,3),'filled')
    end
    cons = [cons; prs];
end
for i = 1:size(families,1)
    lm_tmp(families{i,3}) = i;
end
coords = histcounts(cons,1:size(families,1)+1).';
families(:,4) = num2cell(coords);
lm = lm_tmp;
f_t=table2cell(regionprops3(lm,'EquivDiameter','Centroid'));
families(:,1:2) = f_t;
%% RL vox only
% t1 = rl + ops;
% t2 = rl - ops;
% t3 = [rl t1 t2];
% t3(t3<= 0 | t3 > numel(lm_fld)) = find(lm_fld == 0,1);
% con_mat = lm_fld(t3);
% for i = 1:size(families,1)
%     con_tmp = nonzeros(unique(con_mat(any(con_mat == i,2),:)));
%     con_tmp(con_tmp<i) = [];
%     prs = nchoosek(con_tmp,2);
%     prs(prs(:,1)~=i,:) = [];
%     cons = [cons; prs];
% end
% coords = histcounts(cons,1:size(families,1)+1).';
%% Arash method
% tic
% B=imdilate(lm_fld,ones(2,2,2));
% C=B; C(:,:,1:end-1)=C(:,:,2:end); 
% D=B; D(:,1:end-1,:)=D(:,2:end,:); 
% E=B; E(1:end-1,:,:)=E(2:end,:,:);
% % detecting neighbours
% F=[B(:) C(:); C(:) D(:); B(:) D(:) ;B(:) E(:) ;C(:) E(:) ;D(:) E(:)];
% F(F(:,1).*F(:,2)==0,:)=[];
% F(F(:,1)==F(:,2),:)=[];
% F=unique(F,'rows');
% % making the connectivity matrix 
% Network=zeros(max(B(:)));
% for I=1:size(F,1)
%    Network(F(I,1),F(I,2)) =1;
%    Network(F(I,2),F(I,1)) =1;
% end
% coordinations = sum(Network,2);
% netreal = tril(Network);
% cons2 = zeros(1,2);
% for i = 1:size(Network,2)
%     locs = find(netreal(:,i)==1);
%     ctmp = [repmat(i,length(locs),1) locs];
%     cons2 = [cons2;ctmp];
% end
% cons2(1,:) = [];
% toc
%% stats
AVERAGE_COORDINATION_NUMBER=mean(coords);
families(:,4) = num2cell(coords);
% visualizing the coordination number distribution 
% subplot(2,2,2)
% histogram(cell2mat(families(:,4)),max(cell2mat(families(:,4)))); xlabel('Coordination Number'); ylabel('Frequency');  title('Coordination Number Distribution');
end