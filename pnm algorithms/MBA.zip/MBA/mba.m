function [m_spheres] = mba(A,m_spheres,con_s)
%% initialise
f = 0;
comp = 0;
%% pre-pro
m_spheres(:,6:8) = [zeros(size(m_spheres,1),1) inf(size(m_spheres,1),1) (1:size(m_spheres,1)).'];
groups = unique(m_spheres(:,4),'stable');
% groups = groups(groups>1);
%% mba
for i = 1:numel(groups)
    disp(['MBA ',num2str(i),'/',num2str(length(groups))])
    for j = 1:sum(m_spheres(:,4) == groups(i))
        grp = m_spheres(m_spheres(:,4) == groups(i),:);
        grp = sortrows(grp,7,'ascend');
        sph_i = grp(j,:);
        if sph_i(6) == 0
            f = f+1;
            fam = f;
            gen = 2;
            sph_i(6:7) = [fam 1];
        else
            fam = sph_i(6);
            gen = sph_i(7) + 1;
        end 
        sph_loc = m_spheres(:,5) == sph_i(5);
        atch = con_s{sph_loc};
        atch_l = ismember(m_spheres(:,5),atch);
        atch_s = m_spheres(atch_l,:);
        sph_ab = atch_s(:,6) == 0;
            if any(sph_ab) == 1 
                atch_s(sph_ab,6:7) = repmat([fam gen],sum(sph_ab),1);
            end
        whl = [sph_i;atch_s];
        whl = sortrows(whl,4,'descend');
        m_spheres(logical(sph_loc+atch_l),:) = whl;
        m_spheres = sortrows(m_spheres,8,'ascend');
        comp = comp+1;
    end
end
%% plotting
% families = unique(m_spheres(:,6));
% [m, n, p,] = sphere(20);
% figure()
% for i = 1:size(families,1)
%     colour = rand(1,3);
%     tmp = m_spheres(m_spheres(:,6) == families(i),1:4);
%     for j = 1:size(tmp,1)
%         x = tmp(j,1); y = tmp(j,2); z = tmp(j,3); r = tmp(j,4);  
%         surf(m.*r+x,n.*r+y,p.*r+z,'FaceColor',colour,'EdgeColor', 'none', 'FaceAlpha',0.75);
%         hold on
% %         axis off
%     end
%     disp(['Families surfaced: ', num2str(i), '/', num2str(size(families,1))])
% end
% set(gca,'XTick',[],'YTick',[],'ZTick',[]);
% set(gca,'XColor',[1 1 1],'YColor',[1 1 1],'ZColor',[1 1 1],'TickDir','out')
% % camlight('left','local');
% daspect([1 1 1])
% xlim([1 164]); ylim([1 164]);
%% vol Plotting
% figure()
% for p = 1:length(se)
%     space = zeros(size(A));
%     colour = rand(1,3);
%     sphs = families{se(p),1}(:,1:3);
%     sphs = ismember(m_spheres(:,1:3),sphs,'rows');
%     inds = unique(cell2mat(m_spheres_t(sphs,2)));
%     [y,x,z] = ind2sub(size(A),inds);
%     k = boundary(x,y,z);
%     trisurf(k,x,y,z,'FaceColor',colour,'EdgeColor','none')
%     hold on
%     disp(['Families surfaced: ', num2str(p), '/', num2str(size(families,1))])
% %     xlim([0 164]); ylim([0 164]); zlim([1 2])
% end   
end