function G = setupgraph(families,cons)
n_t = array2table(cell2mat(families(:,1)),'VariableNames',{'X','Y','Z'});
G = graph(cons(:,1),cons(:,2),cons(:,3),n_t);
end