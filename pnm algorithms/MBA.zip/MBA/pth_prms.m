function anlys = pth_prms(G,spts,fpts)
[SPTS,FPTS] = meshgrid(spts,fpts);
c=cat(2,SPTS',FPTS');
allcombs=reshape(c,[],2);
tb = struct("StartPoint",[],"FinishPoint",[],"Distance",[],"Length",[],"Tortuosity",[],"Orientation",[],"Path",[]);
p = gcp('nocreate'); % If no pool, do not create new one.
if isempty(p)
    parpool
end
C = parallel.pool.Constant(allcombs);
N = size(allcombs, 1); %Total number of calculations 
ppm = ParforProgressStarter2('pth prms', N, 1, 1, 1, 1) %Parallel progress bar from file exchange
ppm = ParforProgress2('pth prms',N);
parfor i = 1:size(allcombs,1)
    p1 = table2array(G.Nodes(C.Value(i,1),:));
    p2 = table2array(G.Nodes(C.Value(i,2),:));
    [P,L] = shortestpath(G,C.Value(i,1),C.Value(i,2));
    tb(i).StartPoint = C.Value(i,1);
    tb(i).FinishPoint = C.Value(i,2);
    tb(i).Distance = pdist2(p1,p2);
    tb(i).Length = L;
    tb(i).Tortuosity = L/pdist2(p1,p2);
    tb(i).Orientation = wrapTo360(rad2deg(atan2(p2(2)-p1(2),p2(1)-p1(1))));
    tb(i).Path = {P};
    ppm.increment(i);
%     if i == 1
%         figure()
%         h = plot(G,'XData',G.Nodes.X,'YData',G.Nodes.Y,'ZData',G.Nodes.Z);
%     end
%     highlight(h,P,'EdgeColor',rand(1,3),'LineWidth',2);
%     hold on
%     if rem(i,roundsize(allcombs,1)/100)) == 0
%         disp(['Percentage Complete: ',num2str(round((i/size(allcombs,1))*100)])
%     end
end
delete(ppm)
%% Plotting
anlys = struct2cell(tb);
if length(size(anlys)) > 2
    anlys = squeeze(anlys);
end
anlys = anlys.';
anlys(isinf(cell2mat(anlys(:,5)))|isnan(cell2mat(anlys(:,5))),:) = [];
subplot(2,2,3)
histogram(cell2mat(anlys(:,5)),25);
title('Tortuosity Distribution Plot')
xlabel('Tortuosity')
ylabel('Frequency')
ani = [cell2mat(anlys(:,5)) round(cell2mat(anlys(:,6)))];
k = 0;
for i = 0:360
    k = k+1;
    loc = ani(:,2) == i;
    mag = mean(ani(loc,1));
    tota(k,1) = i;
    tota(k,2) = mag;
end
tota(isnan(tota(:,2)),:) = [];
subplot(2,2,4)
polarplot(deg2rad(tota(:,1)),tota(:,2))
title('Polar Tortuosity Plot')
thetatickformat('degrees')
rlim([min(tota(:,2)) max(tota(:,2))])
end